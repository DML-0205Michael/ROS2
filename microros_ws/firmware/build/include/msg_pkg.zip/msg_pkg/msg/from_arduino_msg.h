// generated from rosidl_generator_c/resource/idl.h.em
// with input from msg_pkg:msg/FromArduinoMsg.idl
// generated code does not contain a copyright notice

#ifndef MSG_PKG__MSG__FROM_ARDUINO_MSG_H_
#define MSG_PKG__MSG__FROM_ARDUINO_MSG_H_

#include "msg_pkg/msg/detail/from_arduino_msg__struct.h"
#include "msg_pkg/msg/detail/from_arduino_msg__functions.h"
#include "msg_pkg/msg/detail/from_arduino_msg__type_support.h"

#endif  // MSG_PKG__MSG__FROM_ARDUINO_MSG_H_
