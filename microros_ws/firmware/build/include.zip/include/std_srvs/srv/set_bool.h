// generated from rosidl_generator_c/resource/idl.h.em
// with input from std_srvs:srv/SetBool.idl
// generated code does not contain a copyright notice

#ifndef STD_SRVS__SRV__SET_BOOL_H_
#define STD_SRVS__SRV__SET_BOOL_H_

#include "std_srvs/srv/detail/set_bool__struct.h"
#include "std_srvs/srv/detail/set_bool__functions.h"
#include "std_srvs/srv/detail/set_bool__type_support.h"

#endif  // STD_SRVS__SRV__SET_BOOL_H_
